import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-end-nav',
  templateUrl: './end-nav.component.html',
  styleUrls: ['./end-nav.component.scss']
})
export class EndNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
