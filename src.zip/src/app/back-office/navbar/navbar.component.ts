import { Stock } from 'src/Model/Stock';
import { Component, OnInit } from '@angular/core';
import { StockService } from '../stock/stock.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent implements OnInit {
  constructor(private serviceStock: StockService) {}

  listStock: Stock[];
  ngOnInit(): void {
    this.getAllStock();
  }
  getAllStock() {
    this.serviceStock.getAllStockEnRupture().subscribe((res) => {
      this.listStock = res;
      console.log(res);
    });
  }
  updateStock(stock: Stock) {
    stock.status = true;
    this.serviceStock.updateStock(stock).subscribe((res) => {
      this.getAllStock();
    });
  }
}
