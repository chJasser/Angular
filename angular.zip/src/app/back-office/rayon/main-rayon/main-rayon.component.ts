import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-rayon',
  templateUrl: './main-rayon.component.html',
  styleUrls: ['./main-rayon.component.css']
})
export class MainRayonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
